package com.client.springcloudconfigclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcloudconfigclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcloudconfigclientApplication.class, args);
	}

}
