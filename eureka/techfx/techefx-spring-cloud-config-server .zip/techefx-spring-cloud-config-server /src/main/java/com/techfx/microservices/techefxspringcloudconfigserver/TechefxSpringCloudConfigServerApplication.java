package com.techfx.microservices.techefxspringcloudconfigserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechefxSpringCloudConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechefxSpringCloudConfigServerApplication.class, args);
	}

}
