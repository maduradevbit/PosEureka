package com.propertyfileaccessservice.propertyfileaccessservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PropertyFileAccessServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PropertyFileAccessServiceApplication.class, args);
	}

}
