package com.propertyfileaccessservice.propertyfileaccessservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertyFileAccessServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
