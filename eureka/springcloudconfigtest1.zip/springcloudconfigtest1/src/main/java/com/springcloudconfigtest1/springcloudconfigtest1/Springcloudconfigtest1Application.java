package com.springcloudconfigtest1.springcloudconfigtest1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springcloudconfigtest1Application {

	public static void main(String[] args) {
		SpringApplication.run(Springcloudconfigtest1Application.class, args);
	}

}
